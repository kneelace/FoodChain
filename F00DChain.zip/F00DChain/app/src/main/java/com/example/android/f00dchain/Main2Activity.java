package com.example.android.f00dchain;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Main2Activity extends AppCompatActivity {

    String[] mobileArray = {"Coffee","Rasghulle","Maggi","Biscuit/Cookies",
            "Chips","Ladoo/Mithai","Beverages","Cheese/Butter"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ArrayAdapter adapter = new ArrayAdapter<String>(this,R.layout.activity_list, mobileArray);

        ListView listView = (ListView) findViewById(R.id.packFoods);
        listView.setAdapter(adapter);
    }
}
